import { useCallback, useEffect, useRef, useState } from "react";
import { GameOverlays, PlayingHint } from "@/components/game/overlays";
import type { HudState, LumenGame } from "@/game/engine";

const INITIAL: HudState = {
  phase: "title",
  score: 0,
  best: 0,
  combo: 0,
  muted: false,
  shake: true,
};

export function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<LumenGame | null>(null);
  const [hud, setHud] = useState<HudState>(INITIAL);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let game: LumenGame | null = null;

    void import("@/game/engine").then(({ LumenGame }) => {
      if (dead || !canvasRef.current) return;
      game = new LumenGame(canvasRef.current, { onHud: setHud });
      game.start();
      gameRef.current = game;
      window.__lumen = {
        place: () => game?.place(),
        play: () => game?.play(),
        phase: () => game?.phase ?? "title",
        score: () => game?.score ?? 0,
      };
    });

    return () => {
      dead = true;
      game?.destroy();
      gameRef.current = null;
      if (window.__lumen) delete window.__lumen;
    };
  }, []);

  const play = useCallback(() => gameRef.current?.play(), []);
  const pause = useCallback(() => gameRef.current?.pause(), []);
  const resume = useCallback(() => gameRef.current?.resume(), []);
  const restart = useCallback(() => gameRef.current?.restart(), []);
  const menu = useCallback(() => gameRef.current?.menu(), []);
  const toggleMute = useCallback(() => gameRef.current?.toggleMute(), []);
  const api = { play, pause, resume, restart, menu, toggleMute };

  return (
    <div className="relative h-dvh w-full select-none overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onContextMenu={(e) => e.preventDefault()}
      />
      <GameOverlays hud={hud} api={api} />
      <PlayingHint phase={hud.phase} score={hud.score} />
    </div>
  );
}
