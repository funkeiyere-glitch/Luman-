import type { ReactNode } from "react";
import { Pause, Play, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { HudState, Phase } from "@/game/engine";
import { cn } from "@/lib/utils";

type OverlayApi = {
  play: () => void;
  pause: () => void;
  resume: () => void;
  restart: () => void;
  menu: () => void;
  toggleMute: () => void;
};

export function GameOverlays({
  hud,
  api,
}: {
  hud: HudState;
  api: OverlayApi;
}) {
  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col">
      <HudBar hud={hud} api={api} />
      {hud.phase === "title" && <TitleScreen best={hud.best} onPlay={api.play} />}
      {hud.phase === "paused" && (
        <PauseScreen
          onResume={api.resume}
          onRestart={api.restart}
          onMenu={api.menu}
        />
      )}
      {hud.phase === "over" && (
        <OverScreen
          score={hud.score}
          best={hud.best}
          onAgain={api.restart}
          onMenu={api.menu}
        />
      )}
    </div>
  );
}

function HudBar({ hud, api }: { hud: HudState; api: OverlayApi }) {
  const live = hud.phase === "playing" || hud.phase === "paused";
  return (
    <header className="flex items-start justify-between gap-3 px-4 pt-[max(1rem,env(safe-area-inset-top))] sm:px-6">
      <div className="min-w-0">
        <p className="font-display text-[0.7rem] uppercase tracking-[0.22em] text-muted">
          Lumen
        </p>
        {live ? (
          <p className="mt-1 font-display text-4xl leading-none tabular-nums tracking-tight text-fg sm:text-5xl">
            {hud.score}
          </p>
        ) : (
          <p className="mt-1 text-sm text-muted">Best {hud.best}</p>
        )}
      </div>
      <div className="pointer-events-auto flex items-center gap-2">
        {hud.combo >= 2 && live && (
          <span className="rounded-full border border-border bg-surface px-3 py-1.5 text-xs font-medium tabular-nums text-fg">
            Perfect {hud.combo}
          </span>
        )}
        <Button
          type="button"
          variant="ghost"
          size="icon"
          aria-label={hud.muted ? "Unmute" : "Mute"}
          onClick={api.toggleMute}
        >
          {hud.muted ? <VolumeX /> : <Volume2 />}
        </Button>
        {hud.phase === "playing" && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Pause"
            onClick={api.pause}
          >
            <Pause />
          </Button>
        )}
      </div>
    </header>
  );
}

function TitleScreen({ best, onPlay }: { best: number; onPlay: () => void }) {
  return (
    <div className="pointer-events-auto flex flex-1 flex-col items-center justify-center px-6 pb-16 text-center">
      <div className="overlay-in max-w-sm">
        <h1 className="font-display text-[clamp(3.5rem,12vw,5.5rem)] leading-[0.9] tracking-[-0.04em] text-fg text-balance">
          Lumen
        </h1>
        <p className="mx-auto mt-5 max-w-[18rem] text-pretty text-base leading-relaxed text-muted">
          One tap. Line up the slab. Keep the tower rising.
        </p>
        <div className="mt-8 flex flex-col items-center gap-3">
          <Button type="button" size="pill" onClick={onPlay} className="min-w-[11rem]">
            <Play className="size-4" />
            Play
          </Button>
          <p className="text-xs text-subtle">
            Tap, click, or press Space
            {best > 0 ? ` · Best ${best}` : ""}
          </p>
        </div>
      </div>
    </div>
  );
}

function PauseScreen({
  onResume,
  onRestart,
  onMenu,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <Modal>
      <h2 className="font-display text-3xl tracking-tight text-fg">Paused</h2>
      <p className="mt-2 text-sm text-muted">The tower is waiting.</p>
      <div className="mt-6 flex w-full flex-col gap-2">
        <Button type="button" onClick={onResume}>
          Resume
        </Button>
        <Button type="button" variant="outline" onClick={onRestart}>
          <RotateCcw className="size-4" />
          Restart
        </Button>
        <Button type="button" variant="ghost" onClick={onMenu}>
          Menu
        </Button>
      </div>
    </Modal>
  );
}

function OverScreen({
  score,
  best,
  onAgain,
  onMenu,
}: {
  score: number;
  best: number;
  onAgain: () => void;
  onMenu: () => void;
}) {
  const isBest = score > 0 && score >= best;
  return (
    <Modal>
      <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted">
        {isBest ? "New best" : "Tower fell"}
      </p>
      <h2 className="mt-2 font-display text-5xl tabular-nums tracking-tight text-fg">
        {score}
      </h2>
      <p className="mt-2 text-sm text-muted">Best {best}</p>
      <div className="mt-6 flex w-full flex-col gap-2">
        <Button type="button" onClick={onAgain}>
          Play again
        </Button>
        <Button type="button" variant="ghost" onClick={onMenu}>
          Menu
        </Button>
      </div>
    </Modal>
  );
}

function Modal({ children }: { children: ReactNode }) {
  return (
    <div className="flex flex-1 items-center justify-center px-5 pb-10">
      <div
        className={cn(
          "pointer-events-auto overlay-in w-full max-w-[20rem] rounded-[calc(var(--radius-md)+1.25rem)]",
          "border border-border bg-surface p-5 shadow-[0_24px_60px_rgba(0,0,0,0.35)]",
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function PlayingHint({ phase, score }: { phase: Phase; score: number }) {
  if (phase !== "playing" || score > 0) return null;
  return (
    <p className="pointer-events-none absolute inset-x-0 bottom-[max(1.5rem,env(safe-area-inset-bottom))] text-center text-xs tracking-wide text-muted">
      Tap to place
    </p>
  );
}
