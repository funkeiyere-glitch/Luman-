const KEY = "lumen-save";
const SAVE_VERSION = 1;

export type LumenSave = {
  version: number;
  best: number;
  muted: boolean;
  shake: boolean;
};

const defaults: LumenSave = {
  version: SAVE_VERSION,
  best: 0,
  muted: false,
  shake: true,
};

function migrate(raw: LumenSave): LumenSave {
  const s = { ...raw };
  if (s.version === undefined || s.version < 1) s.version = 1;
  return { ...defaults, ...s, version: SAVE_VERSION };
}

export function loadSave(): LumenSave {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...defaults };
    const parsed = JSON.parse(raw) as LumenSave;
    return migrate(parsed);
  } catch {
    return { ...defaults };
  }
}

export function writeSave(partial: Partial<LumenSave>): LumenSave {
  const next = { ...loadSave(), ...partial, version: SAVE_VERSION };
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // private mode / quota — keep playing in-memory
  }
  return next;
}
