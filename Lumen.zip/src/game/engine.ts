import * as THREE from "three";
import { GameAudio } from "./audio";
import { loadSave, writeSave } from "./save";

export type Phase = "title" | "playing" | "paused" | "over";

export type HudState = {
  phase: Phase;
  score: number;
  best: number;
  combo: number;
  muted: boolean;
  shake: boolean;
};

export type EngineHooks = {
  onHud: (state: HudState) => void;
};

const HEIGHT = 0.42;
const START_SIZE = 3.2;
const TRAVEL = 5.4;
const PERFECT = 0.07;
const BASE_SPEED = 3.15;
const MAX_SPEED = 8.2;
const BG = 0x0b0c10;

const RAMP = [
  0xc9cfd8, 0xb8c5c1, 0xd6c8b5, 0xcbb6b0, 0xadb9cc, 0xc5d0c6, 0xd8d2ca, 0xa8b8c8,
];

function lerpColor(a: number, b: number, t: number) {
  const ar = (a >> 16) & 255,
    ag = (a >> 8) & 255,
    ab = a & 255;
  const br = (b >> 16) & 255,
    bg = (b >> 8) & 255,
    bb = b & 255;
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bl = Math.round(ab + (bb - ab) * t);
  return (r << 16) | (g << 8) | bl;
}

function colorForLayer(i: number) {
  const span = RAMP.length;
  const x = ((i % span) + span) % span;
  const i0 = Math.floor(x);
  const i1 = (i0 + 1) % span;
  return lerpColor(RAMP[i0]!, RAMP[i1]!, x - i0);
}

type Falling = {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  rz: number;
};

type Spark = {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
};

function noise(n: number) {
  return Math.sin(n * 127.1) * Math.cos(n * 311.7);
}

export class LumenGame {
  private canvas: HTMLCanvasElement;
  private hooks: EngineHooks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.OrthographicCamera;
  private geo: THREE.BoxGeometry;
  private sparkGeo: THREE.SphereGeometry;
  private audio = new GameAudio();
  private raf = 0;
  private last = 0;
  private acc = 0;
  private running = false;
  private reducedMotion = false;
  private viewSize = 10.5;
  private viewTarget = 10.5;
  private camLookY = 0;
  private camLookTarget = 0;
  private camTheta = Math.PI / 4;
  private trauma = 0;
  private hitstop = 0;
  private baseGroup: THREE.Group;
  private dirLight: THREE.DirectionalLight;

  phase: Phase = "title";
  mode: "demo" | "live" = "demo";
  score = 0;
  best = 0;
  combo = 0;
  muted = false;
  shake = true;

  private sizeX = START_SIZE;
  private sizeZ = START_SIZE;
  private axis: 0 | 1 = 0;
  private dir = 1;
  private speed = BASE_SPEED;
  private moving: THREE.Mesh | null = null;
  private top: THREE.Mesh | null = null;
  private stack: THREE.Mesh[] = [];
  private falling: Falling[] = [];
  private sparks: Spark[] = [];
  private lock = false;
  private demoResetAt = 0;
  private placed = 0;
  private keys = new Set<string>();
  private unbind: Array<() => void> = [];

  constructor(canvas: HTMLCanvasElement, hooks: EngineHooks) {
    this.canvas = canvas;
    this.hooks = hooks;
    const save = loadSave();
    this.best = save.best;
    this.muted = save.muted;
    this.shake = save.shake;
    this.audio.setMuted(this.muted);
    this.reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setClearColor(BG, 1);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(BG);
    this.scene.fog = new THREE.Fog(BG, 18, 42);

    const aspect = 1;
    this.camera = new THREE.OrthographicCamera(
      -this.viewSize * aspect * 0.5,
      this.viewSize * aspect * 0.5,
      this.viewSize * 0.5,
      -this.viewSize * 0.5,
      0.1,
      80,
    );
    this.camera.position.set(11, 13, 11);
    this.camera.lookAt(0, 0, 0);

    this.geo = new THREE.BoxGeometry(1, 1, 1);
    this.sparkGeo = new THREE.SphereGeometry(0.08, 8, 8);

    const hemi = new THREE.HemisphereLight(0x3a4254, 0x0b0c10, 0.85);
    this.scene.add(hemi);
    const amb = new THREE.AmbientLight(0xffffff, 0.18);
    this.scene.add(amb);

    this.dirLight = new THREE.DirectionalLight(0xfff6ea, 1.15);
    this.dirLight.position.set(8, 16, 5);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.set(1024, 1024);
    this.dirLight.shadow.camera.near = 1;
    this.dirLight.shadow.camera.far = 50;
    this.dirLight.shadow.camera.left = -14;
    this.dirLight.shadow.camera.right = 14;
    this.dirLight.shadow.camera.top = 18;
    this.dirLight.shadow.camera.bottom = -10;
    this.dirLight.shadow.bias = -0.0008;
    this.scene.add(this.dirLight);
    this.scene.add(this.dirLight.target);

    this.baseGroup = new THREE.Group();
    this.scene.add(this.baseGroup);

    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x101218,
      roughness: 1,
      metalness: 0,
    });
    const ground = new THREE.Mesh(new THREE.CircleGeometry(18, 48), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.02;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const daisMat = new THREE.MeshStandardMaterial({
      color: 0x171920,
      roughness: 0.85,
      metalness: 0.05,
    });
    const dais = new THREE.Mesh(new THREE.CylinderGeometry(3.1, 3.4, 0.28, 48), daisMat);
    dais.position.y = 0.12;
    dais.receiveShadow = true;
    dais.castShadow = true;
    this.baseGroup.add(dais);

    this.bind();
    this.resetTower();
    this.resize();
    this.emit();
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min((now - this.last) / 1000, 0.1);
      this.last = now;
      this.tick(dt);
    };
    this.raf = requestAnimationFrame(loop);
  }

  play() {
    this.audio.unlock();
    this.mode = "live";
    this.phase = "playing";
    this.resetTower();
    this.emit();
  }

  pause() {
    if (this.phase !== "playing" || this.mode !== "live") return;
    this.phase = "paused";
    this.emit();
  }

  resume() {
    if (this.phase !== "paused") return;
    this.phase = "playing";
    this.emit();
  }

  restart() {
    this.audio.unlock();
    this.mode = "live";
    this.phase = "playing";
    this.resetTower();
    this.emit();
  }

  menu() {
    this.mode = "demo";
    this.phase = "title";
    this.resetTower();
    this.emit();
  }

  toggleMute() {
    this.muted = !this.muted;
    this.audio.setMuted(this.muted);
    writeSave({ muted: this.muted });
    this.emit();
  }

  setShake(on: boolean) {
    this.shake = on;
    writeSave({ shake: on });
    this.emit();
  }

  place() {
    if (this.phase === "paused") return;
    if (this.mode === "live" && this.phase !== "playing") return;
    if (this.mode === "demo" && this.phase !== "title") return;
    if (!this.moving || this.lock) return;
    this.audio.unlock();

    const moving = this.moving;
    const top = this.top;
    if (!top) return;

    const axis = this.axis;
    const size = axis === 0 ? this.sizeX : this.sizeZ;
    const movingCenter = axis === 0 ? moving.position.x : moving.position.z;
    const placedCenter = axis === 0 ? top.position.x : top.position.z;
    const delta = movingCenter - placedCenter;
    const abs = Math.abs(delta);

    if (abs >= size - 0.001) {
      this.dropMesh(moving, Math.sign(delta) * 2.2, 0.4, axis);
      this.moving = null;
      this.audio.whoosh();
      this.fail();
      return;
    }

    const perfect = abs <= PERFECT;
    if (perfect) {
      if (axis === 0) moving.position.x = top.position.x;
      else moving.position.z = top.position.z;
      this.combo += 1;
      this.trauma = Math.min(1, this.trauma + 0.28);
      this.hitstop = this.reducedMotion ? 0 : 0.045;
      this.burst(moving.position, this.combo);
      this.viewTarget = Math.max(9.6, this.viewTarget - 0.12);
    } else {
      this.combo = 0;
      const placedMin = placedCenter - size / 2;
      const placedMax = placedCenter + size / 2;
      const movingMin = movingCenter - size / 2;
      const movingMax = movingCenter + size / 2;
      const oMin = Math.max(placedMin, movingMin);
      const oMax = Math.min(placedMax, movingMax);
      const newSize = oMax - oMin;
      const newCenter = (oMin + oMax) / 2;
      let leftoverCenter: number;
      let leftoverSize: number;
      if (movingMax > placedMax) {
        leftoverSize = movingMax - placedMax;
        leftoverCenter = (placedMax + movingMax) / 2;
      } else {
        leftoverSize = placedMin - movingMin;
        leftoverCenter = (movingMin + placedMin) / 2;
      }

      if (axis === 0) {
        this.sizeX = newSize;
        moving.position.x = newCenter;
        moving.scale.x = newSize;
        this.spawnFalling(
          leftoverCenter,
          moving.position.y,
          moving.position.z,
          leftoverSize,
          HEIGHT,
          this.sizeZ,
          Math.sign(delta) * 2.4,
          0,
        );
      } else {
        this.sizeZ = newSize;
        moving.position.z = newCenter;
        moving.scale.z = newSize;
        this.spawnFalling(
          moving.position.x,
          moving.position.y,
          leftoverCenter,
          this.sizeX,
          HEIGHT,
          leftoverSize,
          0,
          Math.sign(delta) * 2.4,
        );
      }
      this.trauma = Math.min(1, this.trauma + 0.16);
    }

    this.audio.place(perfect, this.combo);
    if (navigator.vibrate && this.mode === "live") {
      navigator.vibrate(perfect ? 12 : 8);
    }

    this.stack.push(moving);
    this.top = moving;
    this.moving = null;
    this.score += 1;
    this.placed += 1;
    if (this.score > this.best) {
      this.best = this.score;
      writeSave({ best: this.best });
    }
    this.camLookTarget = moving.position.y;
    this.viewTarget = 10.2 + this.score * 0.045;
    this.spawnMoving();
    this.emit();
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const off of this.unbind) off();
    this.unbind = [];
    this.clearTower();
    this.geo.dispose();
    this.sparkGeo.dispose();
    this.renderer.dispose();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry && mesh.geometry !== this.geo && mesh.geometry !== this.sparkGeo) {
        mesh.geometry.dispose();
      }
      const mat = mesh.material;
      if (mat) {
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else (mat as THREE.Material).dispose();
      }
    });
  }

  private bind() {
    const onResize = () => this.resize();
    const onKeyDown = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (e.code === "Space" || e.code === "Enter") {
        e.preventDefault();
        this.onConfirm();
      }
      if (e.code === "KeyP" || e.code === "Escape") {
        if (this.phase === "playing") this.pause();
        else if (this.phase === "paused") this.resume();
      }
      if (e.code === "KeyM") this.toggleMute();
    };
    const onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const onBlur = () => this.keys.clear();
    const onPointer = (e: PointerEvent) => {
      if (e.button !== undefined && e.button !== 0) return;
      this.audio.unlock();
      if (this.phase === "playing" && this.mode === "live") {
        e.preventDefault();
        this.place();
      }
    };
    const onVis = () => {
      if (document.hidden && this.phase === "playing" && this.mode === "live") {
        this.pause();
      }
      if (!document.hidden) this.audio.unlock();
    };

    window.addEventListener("resize", onResize);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    this.canvas.addEventListener("pointerdown", onPointer);
    document.addEventListener("visibilitychange", onVis);

    this.unbind.push(() => window.removeEventListener("resize", onResize));
    this.unbind.push(() => window.removeEventListener("keydown", onKeyDown));
    this.unbind.push(() => window.removeEventListener("keyup", onKeyUp));
    this.unbind.push(() => window.removeEventListener("blur", onBlur));
    this.unbind.push(() => this.canvas.removeEventListener("pointerdown", onPointer));
    this.unbind.push(() => document.removeEventListener("visibilitychange", onVis));
  }

  private onConfirm() {
    if (this.phase === "title") this.play();
    else if (this.phase === "playing") this.place();
    else if (this.phase === "paused") this.resume();
    else if (this.phase === "over") this.restart();
  }

  private tick(dt: number) {
    if (this.phase === "paused") {
      this.render(0);
      return;
    }

    if (this.hitstop > 0) {
      this.hitstop -= dt;
      this.render(dt);
      return;
    }

    this.acc += dt;
    const STEP = 1 / 60;
    while (this.acc >= STEP) {
      this.step(STEP);
      this.acc -= STEP;
    }
    this.render(dt);
  }

  private step(dt: number) {
    if (this.moving && (this.phase === "playing" || this.mode === "demo")) {
      const pos = this.axis === 0 ? this.moving.position.x : this.moving.position.z;
      let next = pos + this.dir * this.speed * dt;
      if (next > TRAVEL) {
        next = TRAVEL;
        this.dir = -1;
      } else if (next < -TRAVEL) {
        next = -TRAVEL;
        this.dir = 1;
      }
      if (this.axis === 0) this.moving.position.x = next;
      else this.moving.position.z = next;
    }

    if (this.mode === "demo" && this.phase === "title") {
      if (this.demoResetAt) {
        if (performance.now() > this.demoResetAt) {
          this.demoResetAt = 0;
          this.resetTower();
        }
      } else if (this.moving && this.top) {
        const movingC =
          this.axis === 0 ? this.moving.position.x : this.moving.position.z;
        const placedC = this.axis === 0 ? this.top.position.x : this.top.position.z;
        const slop = 0.1 + this.score * 0.012;
        if (Math.abs(movingC - placedC) < slop) this.place();
      }
    }

    for (let i = this.falling.length - 1; i >= 0; i--) {
      const f = this.falling[i]!;
      f.vy -= 26 * dt;
      f.mesh.position.x += f.vx * dt;
      f.mesh.position.y += f.vy * dt;
      f.mesh.position.z += f.vz * dt;
      if (!this.reducedMotion) {
        f.mesh.rotation.x += f.rx * dt;
        f.mesh.rotation.z += f.rz * dt;
      }
      if (f.mesh.position.y < -8) {
        this.disposeMesh(f.mesh);
        this.falling.splice(i, 1);
      }
    }

    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const s = this.sparks[i]!;
      s.life -= dt;
      s.vy -= 6 * dt;
      s.mesh.position.x += s.vx * dt;
      s.mesh.position.y += s.vy * dt;
      s.mesh.position.z += s.vz * dt;
      const t = Math.max(0, s.life / s.max);
      s.mesh.scale.setScalar(0.4 + t * 0.8);
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = t;
      if (s.life <= 0) {
        this.disposeMesh(s.mesh);
        this.sparks.splice(i, 1);
      }
    }

    this.trauma = Math.max(0, this.trauma - dt * 1.8);
    this.camLookY += (this.camLookTarget - this.camLookY) * (1 - Math.exp(-3.2 * dt));
    this.viewSize += (this.viewTarget - this.viewSize) * (1 - Math.exp(-2.4 * dt));
  }

  private render(dt: number) {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    const aspect = w / h;
    this.camera.left = -this.viewSize * aspect * 0.5;
    this.camera.right = this.viewSize * aspect * 0.5;
    this.camera.top = this.viewSize * 0.5;
    this.camera.bottom = -this.viewSize * 0.5;
    this.camera.updateProjectionMatrix();

    const lookY = this.camLookY;
    this.camera.position.set(11, 13 + lookY, 11);
    this.dirLight.position.set(8, 16 + lookY, 5);
    this.dirLight.target.position.set(0, lookY, 0);
    this.dirLight.target.updateMatrixWorld();

    const shakeOn = this.shake && !this.reducedMotion;
    const shake = shakeOn ? this.trauma * this.trauma : 0;
    const t = performance.now() * 0.01;
    const ox = shake * 0.18 * noise(t);
    const oy = shake * 0.12 * noise(t + 20);

    const radius = 11 * Math.SQRT2;
    if (this.phase === "over" && !this.reducedMotion) {
      this.camTheta += dt * 0.22;
    } else if (this.phase !== "over") {
      this.camTheta += (Math.PI / 4 - this.camTheta) * (1 - Math.exp(-3 * Math.max(dt, 0.001)));
    }
    this.camera.position.set(
      Math.cos(this.camTheta) * radius,
      13 + lookY,
      Math.sin(this.camTheta) * radius,
    );
    this.camera.lookAt(ox, lookY + oy, 0);

    this.renderer.render(this.scene, this.camera);
  }

  private resize() {
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    if (w < 1 || h < 1) return;
    this.renderer.setSize(w, h, false);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  }

  private resetTower() {
    this.clearTower();
    this.sizeX = START_SIZE;
    this.sizeZ = START_SIZE;
    this.axis = 0;
    this.dir = 1;
    this.speed = BASE_SPEED;
    this.score = 0;
    this.combo = 0;
    this.placed = 0;
    this.lock = false;
    this.demoResetAt = 0;
    this.camLookY = 0;
    this.camLookTarget = 0;
    this.viewSize = 10.5;
    this.viewTarget = 10.5;
    this.trauma = 0;
    this.camTheta = Math.PI / 4;

    const base = this.makeBlock(this.sizeX, this.sizeZ, colorForLayer(0), HEIGHT / 2 + 0.26);
    this.stack.push(base);
    this.top = base;
    this.spawnMoving();
  }

  private clearTower() {
    for (const m of this.stack) this.disposeMesh(m);
    this.stack = [];
    if (this.moving) this.disposeMesh(this.moving);
    this.moving = null;
    this.top = null;
    for (const f of this.falling) this.disposeMesh(f.mesh);
    this.falling = [];
    for (const s of this.sparks) this.disposeMesh(s.mesh);
    this.sparks = [];
  }

  private spawnMoving() {
    if (!this.top) return;
    this.axis = this.axis === 0 ? 1 : 0;
    this.dir = Math.random() < 0.5 ? 1 : -1;
    this.speed = Math.min(MAX_SPEED, BASE_SPEED + this.score * 0.085);
    const y = this.top.position.y + HEIGHT;
    const mesh = this.makeBlock(
      this.sizeX,
      this.sizeZ,
      colorForLayer(this.score + 1),
      y,
    );
    if (this.axis === 0) {
      mesh.position.x = this.dir * TRAVEL;
      mesh.position.z = this.top.position.z;
    } else {
      mesh.position.z = this.dir * TRAVEL;
      mesh.position.x = this.top.position.x;
    }
    this.moving = mesh;
    this.lock = false;
  }

  private makeBlock(sx: number, sz: number, color: number, y: number) {
    const mat = new THREE.MeshStandardMaterial({
      color,
      roughness: 0.42,
      metalness: 0.08,
      emissive: color,
      emissiveIntensity: 0.07,
    });
    const mesh = new THREE.Mesh(this.geo, mat);
    mesh.scale.set(sx, HEIGHT, sz);
    mesh.position.set(this.top ? this.top.position.x : 0, y, this.top ? this.top.position.z : 0);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    return mesh;
  }

  private spawnFalling(
    x: number,
    y: number,
    z: number,
    sx: number,
    sy: number,
    sz: number,
    vx: number,
    vz: number,
  ) {
    const color = colorForLayer(this.score + 1);
    const mat = new THREE.MeshStandardMaterial({
      color,
      roughness: 0.45,
      metalness: 0.08,
    });
    const mesh = new THREE.Mesh(this.geo, mat);
    mesh.scale.set(sx, sy, sz);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    this.scene.add(mesh);
    this.falling.push({
      mesh,
      vx,
      vy: 0.6,
      vz,
      rx: (Math.random() * 2 - 1) * 3,
      rz: (Math.random() * 2 - 1) * 3,
    });
  }

  private dropMesh(mesh: THREE.Mesh, along: number, _unused: number, axis: 0 | 1) {
    this.scene.add(mesh);
    this.falling.push({
      mesh,
      vx: axis === 0 ? along : 0,
      vy: 0.2,
      vz: axis === 1 ? along : 0,
      rx: 2.4,
      rz: -1.6,
    });
  }

  private burst(origin: THREE.Vector3, combo: number) {
    const n = this.reducedMotion ? 4 : 10 + Math.min(combo, 6);
    for (let i = 0; i < n; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xf2efe8,
        transparent: true,
        opacity: 1,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.sparkGeo, mat);
      mesh.position.copy(origin);
      mesh.position.y += HEIGHT * 0.4;
      this.scene.add(mesh);
      const ang = Math.random() * Math.PI * 2;
      const sp = 1.2 + Math.random() * 2.2;
      this.sparks.push({
        mesh,
        vx: Math.cos(ang) * sp,
        vy: 1.4 + Math.random() * 1.8,
        vz: Math.sin(ang) * sp,
        life: 0.45 + Math.random() * 0.25,
        max: 0.7,
      });
    }
  }

  private fail() {
    this.audio.gameOver();
    this.trauma = 0.7;
    if (this.mode === "demo") {
      this.demoResetAt = performance.now() + 1600;
      return;
    }
    this.phase = "over";
    this.emit();
  }

  private disposeMesh(mesh: THREE.Mesh) {
    this.scene.remove(mesh);
    const mat = mesh.material;
    if (mat) {
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat.dispose();
    }
  }

  private emit() {
    this.hooks.onHud({
      phase: this.phase,
      score: this.score,
      best: this.best,
      combo: this.combo,
      muted: this.muted,
      shake: this.shake,
    });
  }
}

declare global {
  interface Window {
    __lumen?: {
      place: () => void;
      play: () => void;
      phase: () => Phase;
      score: () => number;
    };
  }
}
